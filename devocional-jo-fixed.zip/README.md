# Devocional Infantil - História de Jó (versão corrigida)

Este é um projeto React + Tailwind para a página low ticket do Devocional Infantil.

## 🚀 Como rodar localmente

1. Clone este repositório
2. Instale dependências:
   ```bash
   npm install
   ```
3. Inicie o servidor local:
   ```bash
   npm start
   ```

## 🌍 Deploy no Netlify

- Certifique-se que o arquivo `public/index.html` está presente.
- Build command: `npm run build`
- Publish directory: `build`

## 🌍 Deploy no Vercel

- Suba este projeto em um repositório GitHub.
- Acesse [Vercel](https://vercel.com), clique em **New Project**, e conecte o repositório.
- Deploy automático em minutos.

---
